# Few Shot Classification


## Get Started
If you're new of mmfewshot, you can check out [Get Started](https://mmfewshot.readthedocs.io/en/latest/index.html)
and [Classification Tutorials](https://mmfewshot.readthedocs.io/en/latest/classification/index.html) to try out MMFewShot.

## Data Preparation
Please follow [DATA Preparation](https://github.com/open-mmlab/mmfewshot/tree/main/tools/data/classification) to prepare data.
