_base_ = [
    '../../_base_/meta_test/poc_meta-test_5way-300shot-vis.py',
    '../../_base_/runtime/epoch_based_runtime.py',
    '../../_base_/schedules/sgd_200epoch.py'
]

img_size = 84
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], std=[58.395, 57.12, 57.375], to_rgb=True)
train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='RandomResizedCrop', size=img_size),
    dict(type='RandomFlip', flip_prob=0.5, direction='horizontal'),
    dict(type='ColorJitter', brightness=0.4, contrast=0.4, saturation=0.4),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='ImageToTensor', keys=['img']),
    dict(type='ToTensor', keys=['gt_label']),
    dict(type='Collect', keys=['img', 'gt_label'])
]

meta_finetune_cfg = dict(
    num_steps=600,
    optimizer=dict(
        type='SGD', lr=0.01, momentum=0.9, dampening=0.9, weight_decay=0.001))

num_new_ways=2
num_video_vis=1

data = dict(
    samples_per_gpu=64,
    workers_per_gpu=8,
    train=dict(
        type='POCDataset',
        data_prefix='data/POC',
        subset='train',
        pipeline=train_pipeline),
    val=dict(
        meta_test_cfg=dict(
            fast_test=True,
            support=dict(
                batch_size=4, drop_last=True, train=meta_finetune_cfg))),
    test=dict(
        num_ways=num_new_ways,
        meta_test_cfg=dict(
        fast_test=True,
        support=dict(
            batch_size=4, drop_last=True, train=meta_finetune_cfg))),
    test_vis=dict(
        num_ways=num_video_vis,
        meta_test_cfg=dict(
            fast_test=True,
            support=dict(
                batch_size=4, drop_last=True, train=meta_finetune_cfg))))

model = dict(
    type='BaselinePlus',
    backbone=dict(type='ResNet12'),
    head=dict(
        type='CosineDistanceHead',
        num_classes=100,
        in_channels=640,
        temperature=10.0),
    meta_test_head=dict(
        type='CosineDistanceHead',
        num_classes=num_new_ways,
        in_channels=640,
        temperature=5.0))
