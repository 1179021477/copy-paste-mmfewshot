_base_ = [
    '../../../_base_/datasets/fine_tune_based/few_shot_poc.py',
    '../../../_base_/schedules/schedule.py', '../../tfa_r101_fpn.py',
    '../../../_base_/default_runtime.py'
]
# classes splits are predefined in FewShotVOCDataset
# FewShotVOCDefaultDataset predefine ann_cfg for model reproducibility.
data = dict(
    train=dict(
        type='FewShotPOCDefaultDataset',
        ann_cfg=[dict(method='TFA', setting='POC_100SHOT')],
        num_novel_shots=100,
        num_base_shots=None,
        classes='NOVEL_CLASSES_POC'),
    val=dict(classes='NOVEL_CLASSES_POC'),
    test=dict(classes='NOVEL_CLASSES_POC'))
evaluation = dict(
    interval=40000,
    class_splits=['NOVEL_CLASSES_POC'])
checkpoint_config = dict(interval=40000)
optimizer = dict(lr=0.001)
lr_config = dict(
    warmup_iters=10, step=[
        36000,
    ])
runner = dict(max_iters=40000)
model = dict(
    roi_head=dict(
        bbox_head=dict(
            num_classes=3)))
# base model needs to be initialized with following script:
#   tools/detection/misc/initialize_bbox_head.py
# please refer to configs/detection/tfa/README.md for more details.
load_from = ('work_dirs/tfa_r101_fpn_poc_base-training/'
             'base_model_random_init_bbox_head.pth')
