# Few Shot Detection

## Get Started
If you're new of mmfewshot, you can check out [Get Started](https://mmfewshot.readthedocs.io/en/latest/index.html)
and [Detection Tutorials](https://mmfewshot.readthedocs.io/en/latest/detection/index.html) to try out MMFewShot.

## Data Preparation
Please follow [DATA Preparation](https://github.com/open-mmlab/mmfewshot/tree/main/tools/data/detection) to prepare data.
