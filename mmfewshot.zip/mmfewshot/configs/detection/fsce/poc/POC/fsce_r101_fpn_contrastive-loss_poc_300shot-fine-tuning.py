_base_ = [
    '../../../_base_/datasets/fine_tune_based/few_shot_poc.py',
    '../../../_base_/schedules/schedule.py',
    '../../fsce_r101_fpn_contrastive_loss.py',
    '../../../_base_/default_runtime.py'
]
# classes splits are predefined in FewShotVOCDataset
# FewShotVOCDefaultDataset predefine ann_cfg for model reproducibility.
data = dict(
    train=dict(
        type='FewShotPOCDefaultDataset',
        ann_cfg=[dict(method='FSCE', setting='POC_300SHOT')],
        num_novel_shots=300,
        num_base_shots=None,
        classes='NOVEL_CLASSES_POC'),
    val=dict(classes='NOVEL_CLASSES_POC'),
    test=dict(classes='NOVEL_CLASSES_POC'))
evaluation = dict(
    interval=7500,
    class_splits=['NOVEL_CLASSES_POC'])
checkpoint_config = dict(interval=7500)
optimizer = dict(lr=0.001)
lr_config = dict(warmup_iters=200, gamma=0.5, step=[8000, 13000])
runner = dict(max_iters=15000)
custom_hooks = [
    dict(
        type='ContrastiveLossDecayHook',
        decay_steps=(6000, 10000),
        decay_rate=0.5)
]
model = dict(
    roi_head=dict(
        bbox_head=dict(
            num_classes=3,
            with_weight_decay=True,
            loss_contrast=dict(iou_threshold=0.8, loss_weight=0.5))))
# base model needs to be initialized with following script:
#   tools/detection/misc/initialize_bbox_head.py
# please refer to configs/detection/fsce/README.md for more details.
load_from = ('work_dirs/fsce_r101_fpn_poc_base-training/'
             'base_model_random_init_bbox_head.pth')
