select_base = "base_list/select_base_3shot-0.4-0.5-10-withlabel.txt"
select_base = "base_list/fsce/select_base-split1-10shot-0.8-withlabel.txt"

Cl =  ['aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car',
           'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike',
           'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor']

f = open(select_base,"r")

few_anno = "data/few_shot_ann/voc/benchmark_10shot/box_10shot"
lines = f.readlines()
count = 0
for line in lines:
    prex = line.split(" ")[0].split("/")[1]
    img_anno = line.split(" ")[0].split("/")[-1].replace(".jpg",".xml")
    anno = "data/VOCdevkit/"+prex+"/Annotations/"+img_anno
    f_ = open(anno,"r")
    lines_f = f_.readlines()
    for c in Cl:
         for l in lines_f:
            if ">"+c+"<" in l:
               target = few_anno +"_"+c+"_train.txt"
               f_t = open(target,"a")
               count += 1
               f_t.write(line.split(" ")[0]+"\n")
               print(count,line,target)
               break
