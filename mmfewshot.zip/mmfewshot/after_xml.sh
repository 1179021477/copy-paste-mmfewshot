rm -rf data/VOCdevkit/VOC2007/Annotations data/VOCdevkit/VOC2007/JPEGImages &&
cp -r data/VOCdevkit/VOC2007/Annotations-origin data/VOCdevkit/VOC2007/Annotations &&
#cp -r data/VOCdevkit/VOC2007/Annotations_1/* data/VOCdevkit/VOC2007/Annotations/ &&
cp -r data/VOCdevkit/VOC2007/JPEGImages-origin data/VOCdevkit/VOC2007/JPEGImages &&
#cp -r data/VOCdevkit/VOC2007/JPEGImages_1/* data/VOCdevkit/VOC2007/JPEGImages/ &&
rm -rf data/VOCdevkit/VOC2012/Annotations data/VOCdevkit/VOC2012/JPEGImages &&
cp -r data/VOCdevkit/VOC2012/Annotations-origin data/VOCdevkit/VOC2012/Annotations &&
#cp -r data/VOCdevkit/VOC2012/Annotations_1/* data/VOCdevkit/VOC2012/Annotations/ &&
cp -r data/VOCdevkit/VOC2012/JPEGImages-origin data/VOCdevkit/VOC2012/JPEGImages #&&
#cp -r  data/VOCdevkit/VOC2012/JPEGImages_1/* data/VOCdevkit/VOC2012/JPEGImages/ &&
#rm -rf data/few_shot_ann/voc/benchmark_1shot &&
#mkdir -p data/few_shot_ann/voc/benchmark_1shot &&
#cp -r data/VOCdevkit/vocsplit/seed0/box_1shot_* data/few_shot_ann/voc/benchmark_1shot/ #&&
#cp -r data/VOCdevkit/VOC2007/JPEGImages_1/* data/VOCdevkit/VOC2012/JPEGImages/ && # appendix
#cp -r data/VOCdevkit/VOC2012/Annotations_1/* data/VOCdevkit/VOC2007/Annotations/ &&
#cp -r  data/VOCdevkit/VOC2012/JPEGImages_1/* data/VOCdevkit/VOC2007/JPEGImages/ #&&
#cp -r data/VOCdevkit/VOC2007/Annotations_1/* data/VOCdevkit/VOC2012/Annotations/ 
