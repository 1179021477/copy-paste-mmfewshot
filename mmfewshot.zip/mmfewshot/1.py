lists = ["tt","ss"]

voc_benchmark = {
        f'SPLIT{split}_{shot}SHOT': [
            dict(
                type='ann_file',
                ann_file=f'data/few_shot_ann/voc/benchmark_{shot}shot/'
                f'box_{shot}shot_{class_name}_train.txt',
                ann_classes=[class_name])
            for class_name in lists
        ]
        for shot in [1] for split in [1, 2, 3]
}
print(voc_benchmark)

voc_benchmark = {}
sets = []
for split in [1, 2, 3]:
        sets = [] 
        for class_name in lists:
            shot = 1
            info = dict(
                type='ann_file',
                ann_file=f'data/few_shot_ann/voc/benchmark_{shot}shot/'
                f'box_{shot}shot_{class_name}_train.txt',
                ann_classes=[class_name])
            sets.append(info)

        voc_benchmark[f'SPLIT{split}_{shot}SHOT'] = sets
print(voc_benchmark)
