cp -r data/coco/trainval2014_gen/* data/coco/trainval2014/
